import struct
import binascii
import math
import codecs
import sys
import os

# definations for parser pass/fail
TC_PASS   =  0
TC_FAIL   =  1

def getUint32(data):
    """!
       This function coverts 4 bytes to a 32-bit unsigned integer.

        @param data : 1-demension byte array  
        @return     : 32-bit unsigned integer
    """ 
    return (data[0] +
            data[1]*256 +
            data[2]*65536 +
            data[3]*16777216)

def getUint16(data):
    """!
       This function coverts 2 bytes to a 16-bit unsigned integer.

        @param data : 1-demension byte array
        @return     : 16-bit unsigned integer
    """ 
    return (data[0] +
            data[1]*256)

def getHex(data):
    """!
       This function coverts 4 bytes to a 32-bit unsigned integer in hex.

        @param data : 1-demension byte array
        @return     : 32-bit unsigned integer in hex
    """ 
    return (binascii.hexlify(data[::-1]))

def checkMagicPattern(data):
    """!
       This function check if data arrary contains the magic pattern which is the start of one mmw demo output packet.  

        @param data : 1-demension byte array
        @return     : 1 if magic pattern is found
                      0 if magic pattern is not found 
    """ 
    found = 0
    if (data[0] == 2 and data[1] == 1 and data[2] == 4 and data[3] == 3 and data[4] == 6 and data[5] == 5 and data[6] == 8 and data[7] == 7):
        found = 1
    return (found)
    
def parse_tlv_header(data, offset):
    tlv_header_format = '2I'
    tlv_header_size = struct.calcsize(tlv_header_format)
    tlv_header = struct.unpack(tlv_header_format, data[offset:offset + tlv_header_size])
    return tlv_header, tlv_header_size
def parser_helper(data, readNumBytes):


    headerStartIndex = -1

    for index in range (readNumBytes):
        if checkMagicPattern(data[index:index+8:1]) == 1:
            headerStartIndex = index
            break
  
    if headerStartIndex == -1: # does not find the magic number i.e output packet header 
        totalPacketNumBytes = -1
        numDetObj           = -1
        numTlv              = -1
        subFrameNumber      = -1
        platform            = -1
        frameNumber         = -1
        timeCpuCycles       = -1
    else: # find the magic number i.e output packet header 
        #magic_words         = getUint32(data[headerStartIndex:headerStartIndex+8:1])
        totalPacketNumBytes = getUint32(data[headerStartIndex+12:headerStartIndex+16:1])
        platform            = getHex(data[headerStartIndex+16:headerStartIndex+20:1])
        frameNumber         = getUint32(data[headerStartIndex+20:headerStartIndex+24:1])
        timeCpuCycles       = getUint32(data[headerStartIndex+24:headerStartIndex+28:1])
        numDetObj           = getUint32(data[headerStartIndex+28:headerStartIndex+32:1])
        numTlv              = getUint32(data[headerStartIndex+32:headerStartIndex+36:1])
        subFrameNumber      = getUint32(data[headerStartIndex+36:headerStartIndex+40:1])
    
    #print("Magic words                         = %d" % ({magic_words}))    
    print("Header_Start_Index                   = %d" % (headerStartIndex))
    print("Total Packet Length(number of bytes) = %d" % (totalPacketNumBytes))
    print("Platform                             = %s" % (platform)) 
    print("Frame Number                         = %d" % (frameNumber)) 
    print("Time (CPU Cycles)                    = %d" % (timeCpuCycles))   
    print("Number of Detected Objects           = %d" % (numDetObj)) 
    print("Number of TLVs                       = %d" % (numTlv))
    print("subFrameNumber                       = %d" % (subFrameNumber))   
                              
    return (headerStartIndex, totalPacketNumBytes, numDetObj, numTlv, subFrameNumber)

def parse_radar_cube(data, offset, tlv_length):
    radar_cube_data = data[offset:offset + tlv_length]
    print('Length of the captured radar cube data = ',len(radar_cube_data),' bytes ')
    complex_data_format = 'hh'  # 16-bit signed integer for imaginary and real parts
    complex_data_size = struct.calcsize(complex_data_format)
    print('Complex data size = ',complex_data_size)
    num_complex_numbers = tlv_length // complex_data_size
    print('Number of complex numbers/ radarcube data elements = ',num_complex_numbers)
    radar_cube = []

    for i in range(num_complex_numbers):
        start = i * complex_data_size
        end = start + complex_data_size
        if end <= len(radar_cube_data):
            imag, real = struct.unpack_from(complex_data_format, radar_cube_data, start)
            radar_cube.append((imag, real))
        else:
            print(f"Error: Attempt to read beyond buffer size at index {i}")
            break

    return radar_cube
def parser_one_mmw_demo_output_packet(data, readNumBytes):
    
    headerNumBytes = 40
    result = TC_PASS
    
    # Assuming parser_helper returns a tuple with the required values
    (headerStartIndex, totalPacketNumBytes, numDetObj, numTlv, subFrameNumber) = parser_helper(data, readNumBytes)
    
    if headerStartIndex == -1:
        result = TC_FAIL
        print("************ Frame Fail, cannot find the magic words *****************")
    else:
        nextHeaderStartIndex = headerStartIndex + totalPacketNumBytes
        
        if headerStartIndex + totalPacketNumBytes > readNumBytes:
            result = TC_FAIL
            print("********** Frame Fail, readNumBytes may not long enough ***********")
        elif nextHeaderStartIndex + 8 < readNumBytes and checkMagicPattern(data[nextHeaderStartIndex:nextHeaderStartIndex+8:1]) == 0:
            result = TC_FAIL
            print("********** Frame Fail, incomplete packet **********") 
        elif numDetObj <= 0:
            result = TC_FAIL
            print("************ Frame Fail, numDetObj = %d *****************" % (numDetObj))
        elif subFrameNumber > 3:
            result = TC_FAIL
            print("************ Frame Fail, subFrameNumber = %d *****************" % (subFrameNumber))
        else:
            print("No problem")
           
            
        tlvStart = headerStartIndex + headerNumBytes
                                                    
        tlvType    = getUint32(data[tlvStart+0:tlvStart+4:1])
        tlvLen     = getUint32(data[tlvStart+4:tlvStart+8:1]) 
        
        offset = 48
                    
        print("The 1st TLV") 
        print("TLV type = %d" % (tlvType))
        print("TLV length = %d bytes" % (tlvLen))
        
        if tlvType == 10 and tlvLen < totalPacketNumBytes:
            no_elements = 0
            radar_cube = parse_radar_cube(data, offset, tlvLen)
            print(f"Radar Cube Data (Imag, Real):")
            for imag, real in radar_cube:
                print(f"  Imaginary: {imag}, Real: {real}")
                no_elements = no_elements + 1
            print('number of elements printed = ',no_elements)
            offset += tlvLen
            print()
            
    




    
def main(file_path):
    with open(file_path, 'rb') as file:
        data = file.read()

    readNumBytes = os.path.getsize(file_path)
  
    print("readNumBytes: ", readNumBytes)
    parser_one_mmw_demo_output_packet(data, readNumBytes)
    
    


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <path_to_dat_file>")
        sys.exit(1)

    file_path = sys.argv[1]
    main(file_path)