import os
import sys
import logging
from parser_mmw_demo import parser_one_mmw_demo_output_packet

##################################################################################
# LOGGING CONFIGURATION
##################################################################################
class StreamToLogger:
    def __init__(self, logger, log_level=logging.INFO):
        self.logger = logger
        self.log_level = log_level
        self.linebuf = ''

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            self.logger.log(self.log_level, line.rstrip())

    def flush(self):
        pass

logging.basicConfig(filename='parser_output.log', level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Redirect stdout to logger
sys.stdout = StreamToLogger(logging.getLogger('STDOUT'), logging.INFO)
sys.stderr = StreamToLogger(logging.getLogger('STDERR'), logging.ERROR)

##################################################################################
# INPUT CONFIGURATION
##################################################################################
# get the captured file name (obtained from Visualizer via 'Record Start')
if len(sys.argv) > 1:
    capturedFileName = sys.argv[1]
else:
    logging.error("Error: provide file name of the saved stream from Visualizer for OOB demo")
    exit()

##################################################################################
# USE parser_mmw_demo SCRIPT TO PARSE ABOVE INPUT FILES
##################################################################################
# Read the entire file 
fp = open(capturedFileName, 'rb')
readNumBytes = os.path.getsize(capturedFileName)
logging.info("readNumBytes: %d", readNumBytes)
allBinData = fp.read()
logging.info("allBinData: %d %d %d %d", allBinData[0], allBinData[1], allBinData[2], allBinData[3])
fp.close()

# init local variables
totalBytesParsed = 0
numFramesParsed = 0

# parser_one_mmw_demo_output_packet extracts only one complete frame at a time
# so call this in a loop till end of file
while totalBytesParsed < readNumBytes:
    
    # parser_one_mmw_demo_output_packet function already prints the
    # parsed data to stdio. So showcasing only saving the data to arrays 
    # here for further custom processing
    parser_result, \
    headerStartIndex,  \
    totalPacketNumBytes, \
    numDetObj,  \
    numTlv,  \
    subFrameNumber,  \
    detectedX_array,  \
    detectedY_array,  \
    detectedZ_array,  \
    detectedV_array,  \
    detectedRange_array,  \
    detectedAzimuth_array,  \
    detectedElevation_array,  \
    detectedSNR_array,  \
    detectedNoise_array = parser_one_mmw_demo_output_packet(allBinData[totalBytesParsed::1], readNumBytes-totalBytesParsed)

    # Check the parser result
    logging.info("Parser result: %d", parser_result)
    if parser_result == 0: 
        totalBytesParsed += (headerStartIndex + totalPacketNumBytes)    
        numFramesParsed += 1
        logging.info("totalBytesParsed: %d", totalBytesParsed)
        ##################################################################################
        # TODO: use the arrays returned by above parser as needed. 
        # For array dimensions, see help(parser_one_mmw_demo_output_packet)
        # help(parser_one_mmw_demo_output_packet)
        ##################################################################################

        
        # For example, dump all S/W objects to a csv file
        import csv
        if numFramesParsed == 1:
            democsvfile = open('mmw_demo_output.csv', 'w', newline='')                
            demoOutputWriter = csv.writer(democsvfile, delimiter=',',
                                    quotechar='', quoting=csv.QUOTE_NONE)                                    
            demoOutputWriter.writerow(["frame", "DetObj#", "x", "y", "z", "v", "snr", "noise"])            
            
        for obj in range(numDetObj):
            demoOutputWriter.writerow([numFramesParsed - 1, obj, detectedX_array[obj],\
                                           detectedY_array[obj],\
                                           detectedZ_array[obj],\
                                           detectedV_array[obj],\
                                           detectedSNR_array[obj],\
                                           detectedNoise_array[obj]])

        
    else: 
        # error in parsing; exit the loop
        break

# All processing done; Exit
logging.info("numFramesParsed: %d", numFramesParsed)
